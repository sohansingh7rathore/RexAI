"use client"

import { Button } from "@/components/ui/button"
import { ArrowRight, Zap, Bot, Workflow } from "lucide-react"

export function HeroSection() {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-br from-background via-accent to-background animate-gradient">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_40%,rgba(255,59,48,0.15),transparent_50%)]" />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_70%_60%,rgba(255,204,2,0.1),transparent_50%)]" />
      </div>

      <div className="absolute top-20 left-10 animate-float">
        <div className="w-16 h-16 rounded-full bg-primary/20 flex items-center justify-center animate-pulse-glow-red">
          <Bot className="w-8 h-8 text-primary" />
        </div>
      </div>
      <div className="absolute top-40 right-20 animate-float" style={{ animationDelay: "2s" }}>
        <div className="w-12 h-12 rounded-full bg-secondary/20 flex items-center justify-center animate-pulse-glow-yellow">
          <Zap className="w-6 h-6 text-secondary" />
        </div>
      </div>
      <div className="absolute bottom-40 left-20 animate-float" style={{ animationDelay: "4s" }}>
        <div className="w-14 h-14 rounded-full bg-primary/20 flex items-center justify-center animate-pulse-glow-red">
          <Workflow className="w-7 h-7 text-primary" />
        </div>
      </div>

      <div className="relative z-10 container mx-auto px-4 text-center">
        <h1 className="text-5xl md:text-7xl font-bold mb-6 text-balance">
          Transforming Businesses with <span className="text-primary">AI Automation</span>
        </h1>
        <p className="text-xl md:text-2xl text-muted-foreground mb-8 max-w-3xl mx-auto text-pretty leading-relaxed">
          We build intelligent automation solutions that streamline your workflows, boost efficiency, and unlock
          unprecedented growth for your business.
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Button size="lg" className="text-lg px-8 py-6 bg-primary hover:bg-primary/90 animate-pulse-glow-red">
            Book a Demo
            <ArrowRight className="ml-2 w-5 h-5" />
          </Button>
          <Button
            size="lg"
            variant="outline"
            className="text-lg px-8 py-6 bg-transparent border-secondary text-secondary hover:bg-secondary hover:text-black"
          >
            Get in Touch
          </Button>
        </div>
      </div>
    </section>
  )
}
