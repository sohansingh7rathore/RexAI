import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { ArrowRight, TrendingUp, Clock, Users } from "lucide-react"

export function CaseStudiesSection() {
  const caseStudies = [
    {
      title: "E-commerce Automation",
      company: "RetailTech Solutions",
      description: "Implemented AI-powered inventory management and customer service automation.",
      results: [
        { icon: TrendingUp, label: "40% Revenue Increase", value: "40%" },
        { icon: Clock, label: "60% Time Saved", value: "60%" },
        { icon: Users, label: "95% Customer Satisfaction", value: "95%" },
      ],
      image: "/modern-e-commerce-dashboard-with-ai-analytics.jpg",
    },
    {
      title: "Healthcare Process Optimization",
      company: "MedFlow Systems",
      description: "Streamlined patient data processing and appointment scheduling with AI automation.",
      results: [
        { icon: Clock, label: "50% Faster Processing", value: "50%" },
        { icon: Users, label: "30% More Patients Served", value: "30%" },
        { icon: TrendingUp, label: "25% Cost Reduction", value: "25%" },
      ],
      image: "/healthcare-automation-dashboard-with-patient-data.jpg",
    },
    {
      title: "Financial Services AI",
      company: "FinanceAI Corp",
      description: "Deployed intelligent fraud detection and automated compliance reporting systems.",
      results: [
        { icon: TrendingUp, label: "99.8% Fraud Detection", value: "99.8%" },
        { icon: Clock, label: "80% Faster Compliance", value: "80%" },
        { icon: Users, label: "100% Accuracy Rate", value: "100%" },
      ],
      image: "/financial-ai-dashboard-with-fraud-detection-analyt.jpg",
    },
  ]

  return (
    <section id="case-studies" className="py-20 bg-accent/50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-6 text-balance">
            Success <span className="text-primary">Stories</span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto text-pretty">
            Real results from real businesses. See how our AI automation solutions have transformed operations and
            delivered measurable outcomes.
          </p>
        </div>

        <div className="space-y-12">
          {caseStudies.map((study, index) => (
            <Card key={index} className="overflow-hidden glass">
              <div className={`grid lg:grid-cols-2 gap-8 ${index % 2 === 1 ? "lg:grid-flow-col-dense" : ""}`}>
                <div className={`p-8 ${index % 2 === 1 ? "lg:col-start-2" : ""}`}>
                  <h3 className="text-3xl font-bold mb-2">{study.title}</h3>
                  <p className="text-primary font-semibold mb-4">{study.company}</p>
                  <p className="text-muted-foreground mb-8 text-pretty">{study.description}</p>

                  <div className="grid grid-cols-3 gap-4 mb-8">
                    {study.results.map((result, resultIndex) => (
                      <div key={resultIndex} className="text-center">
                        <div className="w-12 h-12 bg-primary/20 rounded-full flex items-center justify-center mx-auto mb-2">
                          <result.icon className="w-6 h-6 text-primary" />
                        </div>
                        <div className="text-2xl font-bold text-primary">{result.value}</div>
                        <div className="text-sm text-muted-foreground">{result.label}</div>
                      </div>
                    ))}
                  </div>

                  <Button className="group">
                    View Full Case Study
                    <ArrowRight className="ml-2 w-4 h-4 group-hover:translate-x-1 transition-transform" />
                  </Button>
                </div>

                <div className={`${index % 2 === 1 ? "lg:col-start-1" : ""}`}>
                  <img
                    src={study.image || "/placeholder.svg"}
                    alt={study.title}
                    className="w-full h-full object-cover"
                  />
                </div>
              </div>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
