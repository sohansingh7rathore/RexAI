import { Card } from "@/components/ui/card"
import { Zap, Shield, Rocket, Award } from "lucide-react"

export function WhyChooseUsSection() {
  const reasons = [
    {
      icon: Zap,
      title: "Lightning Fast",
      description: "Rapid deployment and implementation of AI solutions with minimal downtime.",
      stat: "10x Faster",
    },
    {
      icon: Shield,
      title: "Enterprise Security",
      description: "Bank-level security protocols and compliance with industry standards.",
      stat: "99.9% Uptime",
    },
    {
      icon: Rocket,
      title: "Scalable Solutions",
      description: "AI systems that grow with your business and adapt to changing needs.",
      stat: "500% Growth",
    },
    {
      icon: Award,
      title: "Proven Excellence",
      description: "Award-winning team with a track record of successful AI implementations.",
      stat: "200+ Projects",
    },
  ]

  return (
    <section className="py-20">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-6 text-balance">
            Why Choose <span className="text-primary">Our Agency</span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto text-pretty">
            We combine cutting-edge AI technology with deep industry expertise to deliver solutions that drive real
            business value.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {reasons.map((reason, index) => (
            <Card
              key={index}
              className="p-8 text-center glass hover:scale-105 transition-all duration-300 group relative overflow-hidden"
            >
              <div className="absolute top-0 right-0 bg-primary text-primary-foreground px-3 py-1 text-sm font-bold rounded-bl-lg">
                {reason.stat}
              </div>
              <div className="w-20 h-20 bg-primary/20 rounded-full flex items-center justify-center mx-auto mb-6 group-hover:bg-primary/30 transition-colors">
                <reason.icon className="w-10 h-10 text-primary" />
              </div>
              <h3 className="text-2xl font-bold mb-4">{reason.title}</h3>
              <p className="text-muted-foreground text-pretty">{reason.description}</p>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
