import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Bot, Workflow, Database, MessageSquare, Cog, BarChart } from "lucide-react"

export function ServicesSection() {
  const services = [
    {
      icon: Bot,
      title: "AI Chatbots",
      description: "Intelligent conversational AI that handles customer inquiries 24/7 with human-like responses.",
      features: ["Natural Language Processing", "Multi-platform Integration", "Custom Training"],
    },
    {
      icon: Workflow,
      title: "Process Automation",
      description: "Streamline repetitive tasks and workflows to boost productivity and reduce human error.",
      features: ["Workflow Design", "Task Automation", "Process Optimization"],
    },
    {
      icon: Database,
      title: "Data Integration",
      description: "Seamlessly connect and synchronize data across multiple platforms and systems.",
      features: ["API Integrations", "Data Migration", "Real-time Sync"],
    },
    {
      icon: MessageSquare,
      title: "Custom AI Solutions",
      description: "Tailored AI applications designed specifically for your unique business requirements.",
      features: ["Machine Learning Models", "Predictive Analytics", "Custom Development"],
    },
    {
      icon: Cog,
      title: "Workflow Optimization",
      description: "Analyze and improve existing processes using AI-driven insights and recommendations.",
      features: ["Process Analysis", "Bottleneck Identification", "Performance Metrics"],
    },
    {
      icon: BarChart,
      title: "Analytics & Insights",
      description: "Transform raw data into actionable insights with advanced AI-powered analytics.",
      features: ["Data Visualization", "Predictive Modeling", "Business Intelligence"],
    },
  ]

  return (
    <section id="services" className="py-20">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-6 text-balance">
            Our <span className="text-primary">Services</span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto text-pretty">
            Comprehensive AI automation solutions designed to transform your business operations and drive measurable
            results.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <Card key={index} className="p-8 glass hover:scale-105 transition-all duration-300 group">
              <div className="w-16 h-16 bg-primary/20 rounded-full flex items-center justify-center mb-6 group-hover:bg-primary/30 transition-colors">
                <service.icon className="w-8 h-8 text-primary" />
              </div>
              <h3 className="text-2xl font-bold mb-4">{service.title}</h3>
              <p className="text-muted-foreground mb-6">{service.description}</p>
              <ul className="space-y-2 mb-6">
                {service.features.map((feature, featureIndex) => (
                  <li key={featureIndex} className="flex items-center text-sm">
                    <div className="w-2 h-2 bg-primary rounded-full mr-3" />
                    {feature}
                  </li>
                ))}
              </ul>
              <Button
                variant="outline"
                className="w-full group-hover:bg-primary group-hover:text-primary-foreground transition-colors bg-transparent"
              >
                Learn More
              </Button>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
