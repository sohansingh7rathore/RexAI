import { Card } from "@/components/ui/card"
import { Target, Users, Lightbulb } from "lucide-react"

export function AboutSection() {
  return (
    <section id="about" className="py-20 bg-accent/50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-6 text-balance">
            About Our <span className="text-primary">AI Agency</span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto text-pretty">
            We are a forward-thinking AI automation agency dedicated to helping businesses harness the power of
            artificial intelligence to optimize operations and drive growth.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8 mb-16">
          <Card className="p-8 text-center glass hover:scale-105 transition-transform duration-300">
            <div className="w-16 h-16 bg-primary/20 rounded-full flex items-center justify-center mx-auto mb-6">
              <Target className="w-8 h-8 text-primary" />
            </div>
            <h3 className="text-2xl font-bold mb-4">Our Mission</h3>
            <p className="text-muted-foreground">
              To democratize AI technology and make intelligent automation accessible to businesses of all sizes.
            </p>
          </Card>

          <Card className="p-8 text-center glass hover:scale-105 transition-transform duration-300">
            <div className="w-16 h-16 bg-primary/20 rounded-full flex items-center justify-center mx-auto mb-6">
              <Users className="w-8 h-8 text-primary" />
            </div>
            <h3 className="text-2xl font-bold mb-4">Our Team</h3>
            <p className="text-muted-foreground">
              Expert AI engineers, data scientists, and automation specialists with years of industry experience.
            </p>
          </Card>

          <Card className="p-8 text-center glass hover:scale-105 transition-transform duration-300">
            <div className="w-16 h-16 bg-primary/20 rounded-full flex items-center justify-center mx-auto mb-6">
              <Lightbulb className="w-8 h-8 text-primary" />
            </div>
            <h3 className="text-2xl font-bold mb-4">Our Vision</h3>
            <p className="text-muted-foreground">
              A future where AI-powered automation enables businesses to focus on innovation and strategic growth.
            </p>
          </Card>
        </div>
      </div>
    </section>
  )
}
